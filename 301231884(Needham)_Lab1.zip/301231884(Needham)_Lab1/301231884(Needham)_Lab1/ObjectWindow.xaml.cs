﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.Win32;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _301231884_Needham__Lab1
{
    /// <summary>
    /// Interaction logic for ObjectWindow.xaml
    /// </summary>
    public partial class ObjectWindow : Window
    {
        private string selectedFilePath;
        public readonly IAmazonS3 s3Client;
        public ObjectWindow()
        {
            InitializeComponent();
            // Initialize the Amazon S3 client with your AWS credentials
            s3Client = new AmazonS3Client("AKIAXEFUNDUJ6ZUVDO6P", "UkyevXpiR+v0bcPSrPQ2kvDt1C2dmOZSItu0jZMY", Amazon.RegionEndpoint.USEast1);
            LoadBucketsAsync();

        }

        // Method to load all buckets into ComboBox
        private async Task LoadBucketsAsync()
        {
            try
            {
                var buckets = await s3Client.ListBucketsAsync();

                List<string> bucketList = new List<string>();
                foreach (S3Bucket bucket in buckets.Buckets)
                {
                    bucketList.Add(bucket.BucketName);
                }

                // Bind bucket names to ComboBox
                BucketComboBox.ItemsSource = bucketList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching buckets: " + ex.Message);
            }
        }

        // Browse for file to upload
        private void btnBrowseFiles_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                bool? success = openFileDialog.ShowDialog();

                if (success == true)
                {
                    selectedFilePath = openFileDialog.FileName;
                    FileNametxtBox.Text = selectedFilePath;  // Display selected file path in TextBox
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error selecting file: " + ex.Message);
            }
        }

       

        // Method to load objects from the selected bucket into the DataGrid
        private async Task LoadObjectsFromBucketAsync(string bucketName)
        {
            try
            {
                var listObjectsRequest = new ListObjectsV2Request
                {
                    BucketName = bucketName
                };

                var listObjectsResponse = await s3Client.ListObjectsV2Async(listObjectsRequest);
                List<S3ObjectModel> objectList = new List<S3ObjectModel>();

                foreach (S3Object obj in listObjectsResponse.S3Objects)
                {
                    objectList.Add(new S3ObjectModel
                    {
                        ObjectName = obj.Key,
                        ObjectSize = obj.Size
                    });
                }

                // Bind object list to DataGrid
                ObjectsDataGrid.ItemsSource = objectList;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching objects from bucket: {ex.Message}");
            }
        }

        // Trigger object list refresh when bucket is selected in ComboBox
        private async void BucketComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BucketComboBox.SelectedItem != null)
            {
                string selectedBucket = BucketComboBox.SelectedItem.ToString();
                await LoadObjectsFromBucketAsync(selectedBucket);  // Load objects in the selected bucket
            }
        }

        // Model class for displaying object information in DataGrid
        public class S3ObjectModel
        {
            public string ObjectName { get; set; }  // Object (file) name
            public long ObjectSize { get; set; }  // Object size in bytes
        }

        private void btnPreviousPage_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private async void btnUpload_Click(object sender, RoutedEventArgs e)
        {

            // Ensure a bucket is selected from the ComboBox
            if (BucketComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a bucket.");
                return;
            }

            // Ensure a file is selected to upload
            if (string.IsNullOrEmpty(selectedFilePath))
            {
                MessageBox.Show("Please select a file to upload.");
                return;
            }

            string selectedBucket = BucketComboBox.SelectedItem.ToString();  // Get the selected bucket

            try
            {
                // Create request to upload the file
                var putRequest = new PutObjectRequest
                {
                    BucketName = selectedBucket,
                    FilePath = selectedFilePath,
                    Key = System.IO.Path.GetFileName(selectedFilePath)  // Use file name as the object key
                };

                // Upload the file to the selected S3 bucket
                await s3Client.PutObjectAsync(putRequest);

                // Show success message after upload
                MessageBox.Show("File uploaded successfully!");

                // Refresh the object list for the selected bucket
                await LoadObjectsFromBucketAsync(selectedBucket);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error uploading file: {ex.Message}");
            }
        }
    }
}