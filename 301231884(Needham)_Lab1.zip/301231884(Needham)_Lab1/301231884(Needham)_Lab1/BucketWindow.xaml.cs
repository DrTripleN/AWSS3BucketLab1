﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Amazon.S3;
using Amazon.S3.Model;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq.Expressions;

namespace _301231884_Needham__Lab1
{
    /// <summary>
    /// Interaction logic for BucketWindow.xaml
    /// </summary>
    public partial class BucketWindow : Window
    {

        public readonly IAmazonS3 s3Client;
        public BucketWindow()
        {
            InitializeComponent();
            deleteBucketbtn.IsEnabled = false;

            // Initialize the Amazon S3 client with your AWS credentials
            s3Client = new AmazonS3Client("AKIAXEFUNDUJ6ZUVDO6P", "UkyevXpiR+v0bcPSrPQ2kvDt1C2dmOZSItu0jZMY", Amazon.RegionEndpoint.USEast1);

            LoadBucketsAsync();
        }

        // Fetch the list of buckets and bind it to the DataGrid
        private async Task LoadBucketsAsync()
        {
            try
            {
                var buckets = await s3Client.ListBucketsAsync();
                List<Bucket> bucketList = new List<Bucket>();

                foreach (S3Bucket bucket in buckets.Buckets)
                {
                    var items = await GetItemsInBucket(bucket.BucketName); // Define this method to fetch items
                    bucketList.Add(new Bucket
                    {
                        BucketName = bucket.BucketName,
                        CreationDate = bucket.CreationDate,
                        Items = items 
                    });
                }

                BucketDataGrid.ItemsSource = bucketList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching buckets: " + ex.Message);
            }
        }
        private async Task<List<Item>> GetItemsInBucket(string bucketName)
        {
            var items = new List<Item>();

           
            var listRequest = new ListObjectsV2Request
            {
                BucketName = bucketName
            };

            var listResponse = await s3Client.ListObjectsV2Async(listRequest);

            foreach (var entry in listResponse.S3Objects)
            {
                items.Add(new Item { ItemName = entry.Key });
            }

            return items;
        }

        public class Item
        {
            public string ItemName { get; set; }
           
        }

        public class Bucket
        {
            public string BucketName { get; set; }
            public DateTime CreationDate { get; set; }

            // Add a property to hold items
            public List<Item> Items { get; set; } = new List<Item>(); 
        }

        public class CreateBucketResponse
        {
            public string RequestId { get; set; }
            public string BucketName { get; set; }
        }
    

    private async void btnCreateBucket_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string bucketName = TxtBucketName.Text;

                if (!string.IsNullOrEmpty(bucketName))
                {
                    // Call the async method to create a bucket
                    var response = await CreateBucket(bucketName);

                    // Show success message if the bucket is created
                    MessageBox.Show($"Bucket '{response.BucketName}' Created Successfully with Request ID: {response.RequestId}");

                  // Assuming you have a method to refresh bucket list
                    await LoadBucketsAsync();  
                }
                else
                {
                    MessageBox.Show("Please Enter a Bucket Name");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating bucket: " + ex.Message);
            }
        }

        public async Task<CreateBucketResponse> CreateBucket(string bucketName)
        {
            var putBucketRequest = new PutBucketRequest
            {
                BucketName = bucketName,
                UseClientRegion = true
            };

            var response = await s3Client.PutBucketAsync(putBucketRequest);

            return new CreateBucketResponse
            {
                BucketName = bucketName,
                RequestId = response.ResponseMetadata.RequestId
            };
        }

        private async Task DeleteAllObjectsInBucket(string bucketName)
        {
            ListObjectsV2Response listResponse = null;

            do
            {
                // List objects in the bucket
                listResponse = await s3Client.ListObjectsV2Async(new ListObjectsV2Request
                {
                    BucketName = bucketName,
                    ContinuationToken = listResponse?.NextContinuationToken
                });

                // Create a list of objects to delete
                var deleteRequest = new DeleteObjectsRequest
                {
                    BucketName = bucketName,
                    Objects = listResponse.S3Objects.Select(obj => new KeyVersion { Key = obj.Key }).ToList()
                };

                // Delete the objects in the bucket
                await s3Client.DeleteObjectsAsync(deleteRequest);

            } while (listResponse.IsTruncated); 
        }


        private async void deleteBucketbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedBucket = (Bucket)BucketDataGrid.SelectedItem;

                if (selectedBucket != null)
                {
                    // Fetch items in the bucket
                    var itemsInBucket = await GetItemsInBucket(selectedBucket.BucketName);

                    if (itemsInBucket.Any())
                    {
                        // Confirmation message for deleting all contents and the bucket
                        string confirmMessage = "This will delete all contents in the bucket and the bucket itself. Are you sure you want to proceed?";
                        if (MessageBox.Show(confirmMessage, "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.No)
                        {
                            return;
                        }

                        // Delete all objects in the bucket before deleting the bucket
                        await DeleteAllObjectsInBucket(selectedBucket.BucketName);
                    }
                    else
                    {
                        // If the bucket is empty
                        MessageBox.Show("The selected bucket is being deleted");
                    }

                    // Delete the bucket itself
                    await DeleteBucketAsync(selectedBucket.BucketName);
                    MessageBox.Show($"{selectedBucket.BucketName} and all its contents have been successfully deleted.");
                    await LoadBucketsAsync();
                }
                else
                {
                    MessageBox.Show("Please select a Bucket to delete.");
                }
            }
            catch (AmazonS3Exception s3Ex)
            {
                MessageBox.Show($"Error deleting bucket: {s3Ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"General error: {ex.Message}");
            }
        }


        private async Task DeleteBucketAsync(string bucketName)
        {
            var deleteBucketRequest = new DeleteBucketRequest
            {
                BucketName = bucketName
            };

            await s3Client.DeleteBucketAsync(deleteBucketRequest);
        }

        private void BucketDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            deleteBucketbtn.IsEnabled = true;
        }

        private void btnPreviousScreen_Click(object sender, RoutedEventArgs e)
        {

            this.Hide();

            MainWindow previousWindow = new MainWindow();
           previousWindow.Show();

    
         
        }
    }
}